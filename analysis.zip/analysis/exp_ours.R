library(lme4)
library(lmerTest)
library(merTools)
library(ggplot2)
library(ggthemes)
library(rcompanion)
library(dplyr)
library(RColorBrewer)
library(emmeans)

# 读取数据
if (requireNamespace("rstudioapi", quietly = TRUE) && rstudioapi::isAvailable()) {
  script_dir <- dirname(rstudioapi::getActiveDocumentContext()$path)
  setwd(script_dir)
}

exp1 <- read.csv("output_data/result_for_R.csv")

# 过滤控制试验 (用于检查 engagement)
exp1 <- exp1[!(exp1$trialId %in% c(9000, 9001, 9002, 9003)), ]

exp1$subjectid <- exp1$participantId
# 数据预处理
exp1$correct <- factor(exp1$correct)
exp1$success <- as.numeric(as.character(exp1$correct))

# result.csv 已包含所有 metrics，只需确保数据类型正确
exp1$categorization <- as.numeric(exp1$categorization)
exp1$ciede2000_discriminative <- as.numeric(exp1$ciede2000_discriminative)
exp1$contrast_sensitivity_discriminative <- as.numeric(exp1$contrast_sensitivity)
exp1$hue_discriminative <- as.numeric(exp1$hue_discriminative)
exp1$luminance_variation <- as.numeric(exp1$luminance_variation)
exp1$chromatic_variation <- as.numeric(exp1$chromatic_variation)

# 对数变换和标准化列已存在，直接使用
exp1$log_categorization <- as.numeric(exp1$log_categorization)
exp1$logLAB_Length <- as.numeric(exp1$logLAB_Length)
exp1$log_hue_discriminative <- as.numeric(exp1$log_hue_discriminative)
exp1$log_luminance_variation <- as.numeric(exp1$log_luminance_variation)
exp1$log_chromatic_variation <- as.numeric(exp1$log_chromatic_variation)

# 标准化
exp1$log_categorization_scaled <- scale(exp1$log_categorization)
exp1$ciede2000_scaled <- scale(exp1$ciede2000_discriminative)
exp1$contrast_sensitivity_scaled <- scale(exp1$contrast_sensitivity_discriminative)
exp1$hue_discriminative_scaled <- scale(exp1$hue_discriminative)
exp1$luminance_variation_scaled <- scale(exp1$luminance_variation)
exp1$chromatic_variation_scaled <- scale(exp1$chromatic_variation)

exp1$log_hue_discriminative_scaled <- scale(exp1$log_hue_discriminative)
exp1$log_luminance_variation_scaled <- scale(exp1$log_luminance_variation)
exp1$log_chromatic_variation_scaled <- scale(exp1$log_chromatic_variation)

# Name_Length - result.csv 没有这个变量，创建一个占位符
exp1$Name_Length <- 0

# 构建多个模型
models <- list(
  glmer(correct ~   Name_Length+ (1|subjectid), family = binomial(link = "logit"), data = exp1),
  glmer(correct ~   logLAB_Length + (1|subjectid), family = binomial(link = "logit"), data = exp1),
  glmer(correct ~   log_categorization + (1|subjectid), family = binomial(link = "logit"), data = exp1),
  glmer(correct ~   ciede2000_scaled + (1|subjectid), family = binomial(link = "logit"), data = exp1),
  glmer(correct ~   contrast_sensitivity_scaled + (1|subjectid), family = binomial(link = "logit"), data = exp1),
  glmer(correct ~   hue_discriminative_scaled + (1|subjectid), family = binomial(link = "logit"), data = exp1),
  glmer(correct ~   luminance_variation_scaled + (1|subjectid), family = binomial(link = "logit"), data = exp1),
  glmer(correct ~   chromatic_variation_scaled + (1|subjectid), family = binomial(link = "logit"), data = exp1),
  glmer(correct ~   log_hue_discriminative_scaled + (1|subjectid), family = binomial(link = "logit"), data = exp1),
  glmer(correct ~   log_luminance_variation_scaled + (1|subjectid), family = binomial(link = "logit"), data = exp1),
  glmer(correct ~   log_chromatic_variation_scaled + (1|subjectid), family = binomial(link = "logit"), data = exp1)
)

model_names <- c(
  "Name Length", "log LAB Length", "log Categorization", "CIEDE2000","contrast_sensitivity",
  "Hue", "Luminance", "Chromatic", "log Hue", "log Luminance", "log Chromatic"
)

# 计算 AIC、BIC、固定效应的显著性 p 值和显著性标记
model_comparison <- data.frame(
  Model = model_names,
  AIC = sapply(models, AIC),
  BIC = sapply(models, BIC),
  P_value = sapply(models, function(m) {
    coefs <- summary(m)$coefficients
    # 找到除了 distance 之外的变量
    other_variable <- rownames(coefs)[!(rownames(coefs) %in% c("(Intercept)", "distance"))]
    
    if (length(other_variable) == 1) {
      p_val <- coefs[other_variable, "Pr(>|z|)"]  # 提取 some_variable 的 p 值
    } else {
      p_val <- NA
    }
    
    return(p_val)  # 只返回 p 值
  }),
  Significance = sapply(models, function(m) {
    coefs <- summary(m)$coefficients
    # 找到除了 distance 之外的变量
    other_variable <- rownames(coefs)[!(rownames(coefs) %in% c("(Intercept)", "distance"))]
    
    if (length(other_variable) == 1) {
      p_val <- coefs[other_variable, "Pr(>|z|)"]  # 提取 some_variable 的 p 值
    } else {
      p_val <- NA
    }
    
    # 根据 p 值添加显著性标记
    if (!is.na(p_val)) {
      if (p_val < 0.001) {
        return("***")
      } else if (p_val < 0.01) {
        return("**")
      } else if (p_val < 0.05) {
        return("*")
      } else if (p_val < 0.1) {
        return(".")
      } else {
        return(" ")  # 不显著时返回空格
      }
    } else {
      return("NA")  # 如果 p 值不存在
    }
  })
)

# 输出比较结果
cat("\n============================\n")
cat("模型 AIC/BIC 及显著性比较:\n")
cat("============================\n")
print(model_comparison)

# 选择最优模型（基于 BIC）
selected_model_index <- which.min(model_comparison$BIC)
cat("\n选择的最优模型:", model_comparison$Model[selected_model_index], "\n")


